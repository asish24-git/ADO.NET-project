﻿using Assessment.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class Update : Form
    {
        EmployeeLogic ob;
        public Update()
        {
            InitializeComponent();
            ob = new EmployeeLogic();
        }

        private void Update_Load(object sender, EventArgs e)
        {
            Phonenumlbl.Visible = false;
            Phonenumtxt.Visible = false;
            Emaillbl.Visible = false;
            Emailtxt.Visible = false;
            updatebtn.Visible = false;
            dataGridView1.Visible = false;

        }

        private void chkbtn_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Empidtxt.Text);
            Employee c = ob.serachempid(id);
            if (c == null)
                MessageBox.Show("Enter the valid EMPID as this doesnot exist!!!");
            else
            {
                Phonenumlbl.Visible = true;
                Phonenumtxt.Visible = true;
                Emaillbl.Visible = true;
                Emailtxt.Visible = true;
                updatebtn.Visible = true;
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();

            

            emp.Empid = Convert.ToInt32(Empidtxt.Text);
            emp.Phonenum =long.Parse(Phonenumtxt.Text);
            emp.Email = Emailtxt.Text.ToString();


            string msg = ob.spupdate(emp);

            MessageBox.Show(msg);

            Empidtxt.Text = "";
            Phonenumtxt.Text = "";
            Emailtxt.Text = "";

            dataGridView1.DataSource = ob.getAllData();

            Phonenumlbl.Visible = false;
            Phonenumtxt.Visible = false;
            Emaillbl.Visible = false;
            Emailtxt.Visible = false;
            updatebtn.Visible = false;
            chkbtn.Visible = true;
            dataGridView1.Visible = true;
        }
    }
}
